var searchData=
[
  ['g',['g',['../struct_mvx2_a_p_i_1_1_col.html#a8a5ef4c54f5efe0adc3a5e250f580b98',1,'Mvx2API::Col']]]
];
