var searchData=
[
  ['logger_2eh',['Logger.h',['../_logger_8h.html',1,'']]]
];
