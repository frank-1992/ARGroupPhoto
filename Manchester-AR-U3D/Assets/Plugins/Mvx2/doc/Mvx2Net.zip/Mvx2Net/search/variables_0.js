var searchData=
[
  ['a',['a',['../struct_mvx2_a_p_i_1_1_col.html#a98e7ef356d76e6c1277335d5b33a82cb',1,'Mvx2API::Col']]]
];
