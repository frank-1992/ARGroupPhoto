var searchData=
[
  ['astc_5ftexture_5fdata_5flayer',['ASTC_TEXTURE_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#ae9877447bba528f5cca895b25afcc70a',1,'Mvx2API::BasicDataLayersGuids']]],
  ['audio_5fdata_5flayer',['AUDIO_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#a9fa9004618b6c09da48debd0f13420a8',1,'Mvx2API::BasicDataLayersGuids']]]
];
