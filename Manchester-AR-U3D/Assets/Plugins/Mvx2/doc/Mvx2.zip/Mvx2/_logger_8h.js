var _logger_8h =
[
    [ "IMVXLoggerInstanceListener", "class_m_v_x_1_1_i_m_v_x_logger_instance_listener.html", "class_m_v_x_1_1_i_m_v_x_logger_instance_listener" ],
    [ "MVX2_LOG_DEBUG", "_logger_8h.html#a3726f7b07aaca4c347718865688e6635", null ],
    [ "MVX2_LOG_ERROR", "_logger_8h.html#a20ad0c5fcc2bc30dcf15a728c4383dde", null ],
    [ "MVX2_LOG_INFO", "_logger_8h.html#acac7cbf5d049332c6b89c3942cfddafa", null ],
    [ "MVX2_LOG_VERB", "_logger_8h.html#a5db4632448496689404643bc34e753f1", null ],
    [ "MVX2_LOG_WARN", "_logger_8h.html#a121db5644d505f5010d3256a4fe20671", null ],
    [ "MVX2_SIMPLE_LOG", "_logger_8h.html#a721d367c2eff6e15c637af057056d054", null ],
    [ "MVX2_SIMPLE_TAG", "_logger_8h.html#a11af58a2d313cbda1f1dac983aa57d36", null ],
    [ "MVX2_TAG", "_logger_8h.html#a15a3d6b9606c798a77a19515ec16e999", null ],
    [ "GetMVXLoggerInstance", "_logger_8h.html#a5666726f1bb0bd33ddc9fa21449f0ea9", null ],
    [ "RegisterMVXLoggerInstanceListener", "_logger_8h.html#aeca362be03d745b920ecaa369cc28eb9", null ],
    [ "ResetMVXLoggerInstance", "_logger_8h.html#a50e5de7d24c38224d5dd068ab03ca903", null ],
    [ "SetMVXLoggerInstance", "_logger_8h.html#ad5ff82413a07ec5490582f44ac90ea14", null ],
    [ "UnregisterMVXLoggerInstanceListener", "_logger_8h.html#a8bd2a573ea8d1432768591a29b5ecfa4", null ]
];