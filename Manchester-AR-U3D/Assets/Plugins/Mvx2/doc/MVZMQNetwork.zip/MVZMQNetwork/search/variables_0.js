var searchData=
[
  ['mvx_5fversion',['MVX_VERSION',['../_m_v_z_m_q_network_version_8h.html#a49deb850b0961b8d0027489c8091707b',1,'MVZMQNetwork']]],
  ['mvzmqnetwork_5fversion',['MVZMQNETWORK_VERSION',['../_m_v_z_m_q_network_version_8h.html#a2420a0f8286a2ec9e63a8b0bb71b6dd7',1,'MVZMQNetwork']]]
];
