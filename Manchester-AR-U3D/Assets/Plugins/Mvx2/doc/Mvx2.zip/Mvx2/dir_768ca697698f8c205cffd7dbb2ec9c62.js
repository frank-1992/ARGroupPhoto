var dir_768ca697698f8c205cffd7dbb2ec9c62 =
[
    [ "core", "dir_6be6661c4a1bfe4ef8d07fa1162a8e36.html", "dir_6be6661c4a1bfe4ef8d07fa1162a8e36" ],
    [ "plugins", "dir_177d28fa4e0fd885c653324be58e32fa.html", "dir_177d28fa4e0fd885c653324be58e32fa" ],
    [ "utils", "dir_906946c87bb3e5a0fa9395620c730149.html", "dir_906946c87bb3e5a0fa9395620c730149" ]
];