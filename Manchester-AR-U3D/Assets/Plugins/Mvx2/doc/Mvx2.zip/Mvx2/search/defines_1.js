var searchData=
[
  ['filter_5fdecl',['FILTER_DECL',['../_filter_definition_8h.html#a6d5a20d430471f79c63909b76b8ee8bf',1,'FilterDefinition.h']]],
  ['filter_5fdecl_5fexport',['FILTER_DECL_EXPORT',['../_filter_definition_8h.html#a5db757624f3a9e8b9e254e3c94a48ca4',1,'FilterDefinition.h']]]
];
