var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Related Pages",url:"pages.html"},
{text:"Data Structures",url:"annotated.html",children:[
{text:"Data Structures",url:"annotated.html"},
{text:"Data Structure Index",url:"classes.html"},
{text:"Data Fields",url:"functions.html",children:[
{text:"All",url:"functions.html"},
{text:"Functions",url:"functions_func.html"}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"Globals",url:"globals.html",children:[
{text:"All",url:"globals.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
