var struct_m_v_common_1_1_versorf =
[
    [ "Versorf", "struct_m_v_common_1_1_versorf.html#a4e58753952da400a81ece676bf2a613a", null ],
    [ "CreateRotationAroundAxis", "struct_m_v_common_1_1_versorf.html#abcd3d8a0fb781d621242afd6020b898e", null ],
    [ "CreateRotationFromEulerAnglesZYX", "struct_m_v_common_1_1_versorf.html#abb2408df37863a5deb4028de4176601b", null ],
    [ "CreateRotationFromMatrix", "struct_m_v_common_1_1_versorf.html#aea4b6acbcb1457dfb8d4ec2a78e3db41", null ],
    [ "FromElementsVector", "struct_m_v_common_1_1_versorf.html#afbd30095608d3f7dfa371452769a5620", null ],
    [ "FromRawBytes", "struct_m_v_common_1_1_versorf.html#ab48b8342cb29ecce6616afd941e9689e", null ],
    [ "FromRawElements", "struct_m_v_common_1_1_versorf.html#a660ac8064de884b03e7465327a997d65", null ],
    [ "FromString", "struct_m_v_common_1_1_versorf.html#af6d024a2f276ae94c552a39cae92f4bd", null ],
    [ "Inverted", "struct_m_v_common_1_1_versorf.html#a16aa51cf654afbea1093051b4224f84b", null ],
    [ "ToElementsVector", "struct_m_v_common_1_1_versorf.html#a889c5da4550fceddf6da8f1162162ff9", null ],
    [ "ToEulerAnglesZYX", "struct_m_v_common_1_1_versorf.html#a13c3d5c9a5889f385e6cfda4a9a34eae", null ],
    [ "ToRawBytes", "struct_m_v_common_1_1_versorf.html#aa8c8e35c3c53dfd7826a7f90536534fa", null ],
    [ "ToRawElements", "struct_m_v_common_1_1_versorf.html#ab12f2ef840e662f4e567cd0f98df31ef", null ],
    [ "ToString", "struct_m_v_common_1_1_versorf.html#af61feb65f4e86ba50237c96cc9729ae2", null ],
    [ "RAW_BYTES_SIZE", "struct_m_v_common_1_1_versorf.html#ab482d6cfda9ce7d924b20c3b277bff45", null ]
];