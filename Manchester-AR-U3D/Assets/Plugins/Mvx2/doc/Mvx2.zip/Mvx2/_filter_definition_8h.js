var _filter_definition_8h =
[
    [ "FILTER_DECL", "_filter_definition_8h.html#a6d5a20d430471f79c63909b76b8ee8bf", null ],
    [ "FILTER_DECL_EXPORT", "_filter_definition_8h.html#a5db757624f3a9e8b9e254e3c94a48ca4", null ]
];