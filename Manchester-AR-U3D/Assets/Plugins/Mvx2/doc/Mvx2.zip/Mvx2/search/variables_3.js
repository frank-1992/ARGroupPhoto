var searchData=
[
  ['g',['g',['../struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html#a7e55dc9eedad2016a2ff729ec89bbfe6',1,'Mvx2API::ColRGBAData']]]
];
