var searchData=
[
  ['delegatedframelistener',['DelegatedFrameListener',['../class_mvx2_a_p_i_1_1_delegated_frame_listener.html',1,'Mvx2API']]],
  ['delegatedparametervaluechangedlistener',['DelegatedParameterValueChangedListener',['../class_mvx2_a_p_i_1_1_delegated_parameter_value_changed_listener.html',1,'Mvx2API']]]
];
