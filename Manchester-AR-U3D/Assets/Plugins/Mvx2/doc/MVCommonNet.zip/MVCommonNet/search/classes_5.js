var searchData=
[
  ['iloggersink',['ILoggerSink',['../class_m_v_common_1_1_i_logger_sink.html',1,'MVCommon']]]
];
