var searchData=
[
  ['major',['major',['../struct_m_v_common_1_1_version_info.html#abfe5ec7563f426d55403abb70b0024bd',1,'MVCommon::VersionInfo']]],
  ['minor',['minor',['../struct_m_v_common_1_1_version_info.html#a500dc7071e12a758e45c5e5b271d6c8e',1,'MVCommon::VersionInfo']]],
  ['mvcommon_5fversion',['MVCOMMON_VERSION',['../_m_v_common_version_8h.html#a89fee79a1019b88b06959d8a687124ea',1,'MVCommon']]]
];
