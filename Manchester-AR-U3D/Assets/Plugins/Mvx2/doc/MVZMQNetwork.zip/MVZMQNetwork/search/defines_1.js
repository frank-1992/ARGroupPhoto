var searchData=
[
  ['mvzmqnetwork_5fversion_5fmajor',['MVZMQNETWORK_VERSION_MAJOR',['../_m_v_z_m_q_network_version_8h.html#a9ffbe570b79c4dfdf087b3a80e714424',1,'MVZMQNetworkVersion.h']]],
  ['mvzmqnetwork_5fversion_5fminor',['MVZMQNETWORK_VERSION_MINOR',['../_m_v_z_m_q_network_version_8h.html#afdcb031d084a2de7aeaa79b9866e741d',1,'MVZMQNetworkVersion.h']]],
  ['mvzmqnetwork_5fversion_5fpatch',['MVZMQNETWORK_VERSION_PATCH',['../_m_v_z_m_q_network_version_8h.html#a6e8f6f11848992ca5a764398902f4e10',1,'MVZMQNetworkVersion.h']]]
];
