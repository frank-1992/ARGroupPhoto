var searchData=
[
  ['blue',['blue',['../class_m_v_common_1_1_color.html#a8583bb2f712de64170e63fe52c873b82',1,'MVCommon::Color']]],
  ['bluebyte',['blueByte',['../class_m_v_common_1_1_color.html#ac4b0f47852cf617190f72306d6da2b76',1,'MVCommon::Color']]]
];
