var struct_m_v_common_1_1_version_info =
[
    [ "VersionInfo", "struct_m_v_common_1_1_version_info.html#a19b4fa8c75f93b7ec4d4b1ddc4116c02", null ],
    [ "ToString", "struct_m_v_common_1_1_version_info.html#a5561d1699c6afe6d4ee6504bd4ad1502", null ],
    [ "major", "struct_m_v_common_1_1_version_info.html#abfe5ec7563f426d55403abb70b0024bd", null ],
    [ "minor", "struct_m_v_common_1_1_version_info.html#a500dc7071e12a758e45c5e5b271d6c8e", null ],
    [ "patch", "struct_m_v_common_1_1_version_info.html#a260b389f1deca8ef25ac0d4c26dc2e42", null ]
];