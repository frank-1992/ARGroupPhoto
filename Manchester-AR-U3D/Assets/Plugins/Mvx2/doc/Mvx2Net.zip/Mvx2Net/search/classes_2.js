var searchData=
[
  ['col',['Col',['../struct_mvx2_a_p_i_1_1_col.html',1,'Mvx2API']]]
];
