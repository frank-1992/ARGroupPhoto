var class_mvx2_a_p_i_1_1_graph =
[
    [ "DestroyNativeObject", "class_mvx2_a_p_i_1_1_graph.html#abdaaf65992e19a91a660453f85d3435c", null ],
    [ "Reinitialize", "class_mvx2_a_p_i_1_1_graph.html#a4100e183690e929ff5795031359a812d", null ],
    [ "nativeGraphObject", "class_mvx2_a_p_i_1_1_graph.html#a6fd7e3d7e54e17be363f78b08f94bda2", null ]
];