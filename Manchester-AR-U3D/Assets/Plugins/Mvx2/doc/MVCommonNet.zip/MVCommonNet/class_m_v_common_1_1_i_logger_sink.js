var class_m_v_common_1_1_i_logger_sink =
[
    [ "DestroyNativeObject", "class_m_v_common_1_1_i_logger_sink.html#ae2622f9668c8060c5e92a53beebeeee5", null ],
    [ "LogLevel", "class_m_v_common_1_1_i_logger_sink.html#a9239a0039980e3f2a586d18f891bc96f", null ],
    [ "nativeLoggerSinkObject", "class_m_v_common_1_1_i_logger_sink.html#a215b8996395dbca6155267439be7ad95", null ]
];