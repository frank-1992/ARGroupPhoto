var NAVTREE =
[
  [ "MVX2File", "index.html", [
    [ "Mantis Vision: MVX2File", "index.html", "index" ],
    [ "Source filters", "source_filters.html", "source_filters" ],
    [ "Target filters", "target_filters.html", "target_filters" ]
  ] ]
];

var NAVTREEINDEX =
[
"_source_m_v_x2_file_reader.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';