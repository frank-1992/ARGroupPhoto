var indexSectionsWithContent =
{
  0: "mrsu",
  1: "mrsu"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

