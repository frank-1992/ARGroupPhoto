var dir_177d28fa4e0fd885c653324be58e32fa =
[
    [ "PluginDatabase.h", "_plugin_database_8h.html", "_plugin_database_8h" ],
    [ "PluginInfo.h", "_plugin_info_8h.html", "_plugin_info_8h" ]
];