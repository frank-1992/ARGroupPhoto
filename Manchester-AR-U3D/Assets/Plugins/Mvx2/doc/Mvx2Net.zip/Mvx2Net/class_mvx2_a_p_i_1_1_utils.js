var class_mvx2_a_p_i_1_1_utils =
[
    [ "GetAppExeDirectory", "class_mvx2_a_p_i_1_1_utils.html#aeca5e0eda548221b62768abcbf23d660", null ],
    [ "GetAppExeFilePath", "class_mvx2_a_p_i_1_1_utils.html#a4ca2063d5a1540b7e5eddd3efc48c77a", null ],
    [ "MVXGuidAliasDatabase", "class_mvx2_a_p_i_1_1_utils.html#a6ee91f815baa348a369c3da51da1018e", null ],
    [ "MVXLoggerInstance", "class_mvx2_a_p_i_1_1_utils.html#a8b712491ebf3a5d409fb7ff53f0c9e09", null ]
];