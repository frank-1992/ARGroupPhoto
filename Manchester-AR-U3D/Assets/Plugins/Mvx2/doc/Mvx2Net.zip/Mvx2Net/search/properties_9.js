var searchData=
[
  ['segment_5finfo_5fdata_5flayer',['SEGMENT_INFO_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#aeca76cb51caf9914d060c277bfeff683',1,'Mvx2API::BasicDataLayersGuids']]]
];
