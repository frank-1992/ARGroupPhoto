var _protocol_8h =
[
    [ "CURRENT_PROTOCOL_VERSION", "_protocol_8h.html#ad962153a88c418d80a991e01d0a91376", null ],
    [ "PROTOCOL_VERSION_1", "_protocol_8h.html#afaf87335111ee27362214a47b4b90882", null ],
    [ "PROTOCOL_VERSION_2", "_protocol_8h.html#a2046c437f8ba891830451b4d77f4ad84", null ],
    [ "PROTOCOL_VERSION_3", "_protocol_8h.html#ac327d52776f33a8554dfcf15e05f5c32", null ],
    [ "ProtocolVersion", "_protocol_8h.html#a0da9247f0ea29c7a75e3c1ff272120a3", null ]
];