var NAVTREE =
[
  [ "Mvx2Unity", "index.html", [
    [ "Mantis Vision: Mvx2Unity", "index.html", "index" ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';