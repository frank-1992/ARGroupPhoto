var searchData=
[
  ['mvx2_5flog_5fdebug',['MVX2_LOG_DEBUG',['../_logger_8h.html#a3726f7b07aaca4c347718865688e6635',1,'Logger.h']]],
  ['mvx2_5flog_5ferror',['MVX2_LOG_ERROR',['../_logger_8h.html#a20ad0c5fcc2bc30dcf15a728c4383dde',1,'Logger.h']]],
  ['mvx2_5flog_5finfo',['MVX2_LOG_INFO',['../_logger_8h.html#acac7cbf5d049332c6b89c3942cfddafa',1,'Logger.h']]],
  ['mvx2_5flog_5fverb',['MVX2_LOG_VERB',['../_logger_8h.html#a5db4632448496689404643bc34e753f1',1,'Logger.h']]],
  ['mvx2_5flog_5fwarn',['MVX2_LOG_WARN',['../_logger_8h.html#a121db5644d505f5010d3256a4fe20671',1,'Logger.h']]],
  ['mvx2_5fsimple_5flog',['MVX2_SIMPLE_LOG',['../_logger_8h.html#a721d367c2eff6e15c637af057056d054',1,'Logger.h']]],
  ['mvx2_5fsimple_5ftag',['MVX2_SIMPLE_TAG',['../_logger_8h.html#a11af58a2d313cbda1f1dac983aa57d36',1,'Logger.h']]],
  ['mvx2_5ftag',['MVX2_TAG',['../_logger_8h.html#a15a3d6b9606c798a77a19515ec16e999',1,'Logger.h']]],
  ['mvx_5fplugin',['MVX_PLUGIN',['../_plugin_info_8h.html#a66467fa1f3aaa47ad5e899d2b8d7c0e5',1,'PluginInfo.h']]],
  ['mvx_5fplugin_5fapi',['MVX_PLUGIN_API',['../_plugin_info_8h.html#a742bc0529bb9b2b6714f5a45058f28c6',1,'PluginInfo.h']]],
  ['mvx_5fplugin_5finfo_5fobject_5fname',['MVX_PLUGIN_INFO_OBJECT_NAME',['../_plugin_info_8h.html#af797a566ccfdda3e7c9e7429396beb3e',1,'PluginInfo.h']]],
  ['mvx_5fplugin_5finfo_5fobject_5fname_5fstr',['MVX_PLUGIN_INFO_OBJECT_NAME_STR',['../_plugin_info_8h.html#a43f51443c26174a5a491771b2378531c',1,'PluginInfo.h']]],
  ['mvx_5fversion_5fmajor',['MVX_VERSION_MAJOR',['../_mvx_version_8h.html#a6aa129f88575146fae107c71f8ebe3fe',1,'MvxVersion.h']]],
  ['mvx_5fversion_5fminor',['MVX_VERSION_MINOR',['../_mvx_version_8h.html#a4b3c2bf3aba350b55f0645df488bdc36',1,'MvxVersion.h']]],
  ['mvx_5fversion_5fpatch',['MVX_VERSION_PATCH',['../_mvx_version_8h.html#a20150d52d1a679ccf97230dde2303db5',1,'MvxVersion.h']]]
];
