var dir_a5f8559ccca7d82b18c31da65ed1cbe5 =
[
    [ "FilterCategory.h", "_filter_category_8h.html", "_filter_category_8h" ],
    [ "FilterClassInfo.h", "_filter_class_info_8h_source.html", null ],
    [ "FilterCreator.h", "_filter_creator_8h.html", "_filter_creator_8h" ],
    [ "FilterDefinition.h", "_filter_definition_8h.html", "_filter_definition_8h" ],
    [ "FilterFactory.h", "_filter_factory_8h.html", "_filter_factory_8h" ],
    [ "FilterFactoryIterator.h", "_filter_factory_iterator_8h.html", [
      [ "FilterFactoryIterator", "class_m_v_x_1_1_filter_factory_iterator.html", "class_m_v_x_1_1_filter_factory_iterator" ]
    ] ],
    [ "GenericSharedFilterPtr.h", "_generic_shared_filter_ptr_8h_source.html", null ],
    [ "SharedFilterPtr.h", "core_2filters_2_shared_filter_ptr_8h_source.html", null ]
];