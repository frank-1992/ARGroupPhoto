var searchData=
[
  ['bytearray_5fdata_5flayer',['BYTEARRAY_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#acb3f8900efff7f8a5f66dbc9177dbe14',1,'Mvx2API::BasicDataLayersGuids']]]
];
