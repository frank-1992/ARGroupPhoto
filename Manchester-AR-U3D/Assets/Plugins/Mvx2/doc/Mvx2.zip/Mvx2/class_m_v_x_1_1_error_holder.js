var class_m_v_x_1_1_error_holder =
[
    [ "ErrorHolder", "class_m_v_x_1_1_error_holder.html#a2ec94611cfa1ee2d1ee537f2b2c44206", null ],
    [ "GetLastError", "class_m_v_x_1_1_error_holder.html#a989757f44e1ab1e035f4233ac442dc61", null ],
    [ "ResetError", "class_m_v_x_1_1_error_holder.html#a9dc10b7be110e7d21a4b36f0077f9c0b", null ],
    [ "SetError", "class_m_v_x_1_1_error_holder.html#a9263adab5589c444271b7e7915160eae", null ]
];