var _frame_texture_extractor_8h =
[
    [ "TextureType", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8", [
      [ "TT_DEPTH", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a3a5c5765912d79cf0c129b926aba2894", null ],
      [ "TT_IR", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8ade8bdb0fb08a67a62b6525ac7463c0b8", null ],
      [ "TT_RGB", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a0139afd791beb1542725126099df70e1", null ],
      [ "TT_NVX", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a9292b0769c075b434ec160e33dcf28a2", null ],
      [ "TT_DXT5YCOCG", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a173d73ca781044bb283b3ab83c7bb152", null ],
      [ "TT_DXT1", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a364c5e5636586ef0be488c79834b8504", null ],
      [ "TT_ETC2", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a50d8b6f87ec4a72ab023a4423a8c9563", null ],
      [ "TT_ASTC", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a4b5537f8a044b44161b97bba838f541c", null ],
      [ "TT_NV12", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a39fdb7c7f02ba9762b1e72a8e3279953", null ],
      [ "TT_NV21", "_frame_texture_extractor_8h.html#ace94337dc93b8af45d98cb36765c40c8a238b3be2e19300a75b48afb112967d98", null ]
    ] ],
    [ "CopyTextureData", "_frame_texture_extractor_8h.html#a10efb550b931cafb86fe015e36b8b896", null ],
    [ "GetTextureData", "_frame_texture_extractor_8h.html#a32fae83e1661acb17afd8be2a665b150", null ],
    [ "GetTextureDataSizeInBytes", "_frame_texture_extractor_8h.html#ab65402bccea244f99bc45b7982b3b28d", null ],
    [ "GetTextureResolution", "_frame_texture_extractor_8h.html#a349f0b36641c58344ce715fdedf9d287", null ]
];