var searchData=
[
  ['colrgbadata',['ColRGBAData',['../struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html',1,'Mvx2API']]]
];
