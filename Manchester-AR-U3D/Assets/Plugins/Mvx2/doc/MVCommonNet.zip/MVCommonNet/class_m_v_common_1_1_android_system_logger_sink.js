var class_m_v_common_1_1_android_system_logger_sink =
[
    [ "AndroidSystemLoggerSink", "class_m_v_common_1_1_android_system_logger_sink.html#a1da2a296e52cf65a159c7a89c594cb59", null ]
];