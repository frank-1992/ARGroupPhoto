var class_mvx2_a_p_i_1_1_source_info =
[
    [ "ContainsDataLayer", "class_mvx2_a_p_i_1_1_source_info.html#a1f0e422c08a70fdb784412199f2b9b66", null ],
    [ "ContainsDataLayer", "class_mvx2_a_p_i_1_1_source_info.html#a640c94f453448419f0cb1bc93d764cfe", null ],
    [ "DestroyNativeObject", "class_mvx2_a_p_i_1_1_source_info.html#af8df86ed53f7b46010ec90eb6fe7eacb", null ],
    [ "GetFPS", "class_mvx2_a_p_i_1_1_source_info.html#a878835fb2bfeb275487e0ba5f64f9a2d", null ],
    [ "GetNumFrames", "class_mvx2_a_p_i_1_1_source_info.html#a59be1d03c1f5f08d82a135d838a74797", null ]
];