var _data_layer_definition_8h =
[
    [ "DATALAYER_DECL", "_data_layer_definition_8h.html#a17f13f4f8796456300a793c446ff433f", null ],
    [ "DATALAYER_DECL_EXPORT", "_data_layer_definition_8h.html#a2ad532ca031934a31d55c9ca95a51b01", null ]
];