var searchData=
[
  ['plugindatabase_2eh',['PluginDatabase.h',['../_plugin_database_8h.html',1,'']]],
  ['plugininfo_2eh',['PluginInfo.h',['../_plugin_info_8h.html',1,'']]],
  ['pluginsloader_2eh',['PluginsLoader.h',['../_plugins_loader_8h.html',1,'']]]
];
