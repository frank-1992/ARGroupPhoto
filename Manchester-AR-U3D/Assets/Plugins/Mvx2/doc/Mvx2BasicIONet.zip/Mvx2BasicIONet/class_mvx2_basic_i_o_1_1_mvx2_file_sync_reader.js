var class_mvx2_basic_i_o_1_1_mvx2_file_sync_reader =
[
    [ "Mvx2FileSyncReader", "class_mvx2_basic_i_o_1_1_mvx2_file_sync_reader.html#a89a494567df96534ab5877f850388ecb", null ],
    [ "ReadNextFrame", "class_mvx2_basic_i_o_1_1_mvx2_file_sync_reader.html#a9895d3bef0edf827a5918e48851257c5", null ]
];