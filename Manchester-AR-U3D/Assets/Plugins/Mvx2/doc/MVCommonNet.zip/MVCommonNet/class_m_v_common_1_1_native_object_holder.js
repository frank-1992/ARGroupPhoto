var class_m_v_common_1_1_native_object_holder =
[
    [ "NativeObjectHolder", "class_m_v_common_1_1_native_object_holder.html#aeaa0bb90449f5bb5d2e24e02b0316328", null ],
    [ "DestroyNativeObject", "class_m_v_common_1_1_native_object_holder.html#ab9328466ddb1d81e2dbc8952420343f5", null ],
    [ "Dispose", "class_m_v_common_1_1_native_object_holder.html#a29e01279c8307515e49efa41d894cdba", null ],
    [ "nativeObject", "class_m_v_common_1_1_native_object_holder.html#a32c44a11e8c7332175efc58d824b677e", null ]
];